package user;

public interface User {
		void generateCommunicateRecord();
		void printDetails();
		public  String getCallToPhoneNumber();
		public String accountFee(long timeStart, long timeEnd);

	}



