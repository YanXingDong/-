package student;

public class Student {
	public void Student(){
		System.out.println("This is a student");
		}

}
