package student;

public class Teacher {

	public void  teacher(){
		System.out.println("This is a teacher.");
		}
}
