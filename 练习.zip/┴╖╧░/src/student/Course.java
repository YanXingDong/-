package student;

public class Course {
	public Course(){
		System.out.println("This is a course");
		}

}
